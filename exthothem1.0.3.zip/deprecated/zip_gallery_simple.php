<?php
// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // File upload directory
    $uploadDir = "categories/contents/";

    // Get the uploaded file name
    $zipFileName = basename($_FILES["file"]["name"]);

    // Get the file extension
    $fileExt = strtolower(pathinfo($zipFileName, PATHINFO_EXTENSION));

    // Allowed file extensions
    $allowedExt = array("zip");

    // Check if the uploaded file is a zip file
    if (in_array($fileExt, $allowedExt)) {
        $uploadFilePath = $uploadDir . $zipFileName;

        // Upload the zip file
        if (move_uploaded_file($_FILES["file"]["tmp_name"], $uploadFilePath)) {
            // Extract the zip file
            $zip = new ZipArchive;
            if ($zip->open($uploadFilePath) === TRUE) {
                // Get the folder name (without extension)
                $folderName = pathinfo($zipFileName, PATHINFO_FILENAME);

                // Create a folder if it doesn't exist
                $folderPath = $uploadDir . $folderName . '/';
                if (!file_exists($folderPath)) {
                    mkdir($folderPath, 0755, true);
                }

                // Extract images to the folder
                for ($i = 0; $i < $zip->numFiles; $i++) {
                    $extractedFileName = $zip->getNameIndex($i);
                    $extractedFileExt = strtolower(pathinfo($extractedFileName, PATHINFO_EXTENSION));
                    if (in_array($extractedFileExt, array("jpg", "jpeg", "png", "gif"))) {
                        $extractedFilePath = $folderPath . $extractedFileName;
                        $zip->extractTo($folderPath, array($extractedFileName));
                    }
                }
                $zip->close();
                echo "Zip file uploaded and images extracted successfully.";
            } else {
                echo "Failed to extract zip file.";
            }
            unlink($uploadFilePath); // Delete the uploaded zip file
        } else {
            echo "Failed to upload zip file.";
        }
    } else {
        echo "Only zip files are allowed.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <title>Upload and Extract Zip</title>
</head>

<body>
    <h2>Upload a Zip File</h2>
    <form action="<?php echo $_SERVER["PHP_SELF"]; ?>" method="post" enctype="multipart/form-data">
        <input type="file" name="file" accept=".zip" required>
        <button type="submit">Upload</button>
    </form>
</body>

</html>
