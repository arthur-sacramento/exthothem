<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Content Creation</title>
    <style>
        /* Reset some default styles */
        body, h1, form {
            margin: 0;
            padding: 0;
        }

        /* Page layout and styling */
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            padding: 20px;
        }

        h1 {
            text-align: center;
            margin-bottom: 20px;
        }

        form {
            background-color: #fff;
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
            display: flex; /* Use flex layout */
            flex-wrap: wrap; /* Allow wrapping to the next row */
            justify-content: space-between; /* Space between columns */
        }

        label {
            font-weight: bold;
        }

        .column {
            width: calc(50% - 10px); /* Two columns with a little spacing between */
            margin-bottom: 10px;
        }

        input[type="text"],
        textarea,
        input[type="file"] {
            width: 80%;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            font-size: 16px;
        }

        input[type="file"] {
            padding: 6px;
        }

        input[type="submit"] {
            background-color: #007BFF;
            color: #fff;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            font-size: 16px;
            cursor: pointer;
        }

        input[type="submit"]:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>
    <h1>Content Creation</h1>
    <form action="create.php" method="post" enctype="multipart/form-data">
        <div class="column">
            <label for="thumbnail">Thumbnail</label><br>
            <input type="file" name="thumbnail" id="thumbnail" required>
        </div>

        <div class="column">
            <label for="user">User</label><br>
            <input type="text" name="user" id="user" required>
        </div>

        <div class="column">
            <label for="title">Title</label><br>
            <input type="text" name="title" id="title" required>
        </div>

        <div class="column">
            <label for="url">Link or URL</label><br>
            <input type="text" name="url" id="url" required></textarea>
        </div>

        <div class="column">
            <label for="description">Description</label><br>
            <textarea name="description" id="description" required></textarea>
        </div>

        <div class="column">
            <label for="table">Table</label><br>
            <input type="text" name="table" id="table" required>
        </div>

        <div class="column">
            <input type="submit" value="Submit">
        </div>
    </form>
</body>
</html>

</html>

<?php
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $thumbnailFile = $_FILES["thumbnail"];
    $title = $_POST["title"];   
    $user = $_POST["user"];
    $url = $_POST["url"];
    $description = $_POST["description"];
    $table = $_POST["table"];

    $date = date('Y-m-d');

    $avoid_js_insertion = array ('<','>');       
    $thumbnailFile = str_replace($avoid_js_insertion, "", $thumbnailFile); 
    $title = str_replace($avoid_js_insertion, "", $title);
    $user = str_replace($avoid_js_insertion, "", $user);
    $url = str_replace($avoid_js_insertion, "", $url);
    $description = str_replace($avoid_js_insertion, "", $description); 
    $table = str_replace($avoid_js_insertion, "", $table); 

    // Define the target directory to save the file
    $targetDirectory = "categories/contents/";

    // Check if the target directory exists, and create it if not
    if (!file_exists($targetDirectory)) {
        mkdir($targetDirectory, 0777, true);
    }

    // Get the file extension of the uploaded thumbnail
    $thumbnailExtension = pathinfo($thumbnailFile["name"], PATHINFO_EXTENSION);

    // Generate a unique filename for the thumbnail
    //$thumbnailFileName = $table . "_thumbnail." . $thumbnailExtension;

    $thumbnailFileName = time() . "." . $thumbnailExtension;
   
    // Move the uploaded thumbnail to the target directory
    $thumbnailPath = $targetDirectory . $thumbnailFileName;
    move_uploaded_file($thumbnailFile["tmp_name"], $thumbnailPath);

    $cssFile = "";

    if(!file_exists($targetDirectory . $table . ".html")){
      $cssFile = "<link rel='stylesheet' type='text/css' href='../../containers.css'>";
    }

    // Create an HTML container with the provided data
    $htmlContainer = "$cssFile
        <div class='container'>
            <div class='left-column'>
                <a href='$thumbnailFileName' target='_blank'><img class='thumbnail' src='$thumbnailFileName' alt='Thumbnail'></a>
            </div>
            <div class='right-column'>
                <div class='title'>$title</div>
                <div class='date'>$date</div>
                <div class='user'>$user</div>
                <div class='url'><a href='$url' target='_blank'>$url</a></div>
                <div class='description'>$description</div>
            </div>
        </div>
    ";

    // Save the HTML container to a file with the provided filename
    $contentFilePath = $targetDirectory . $table . ".html";
 
    $fp = fopen($contentFilePath, "a");     
    fwrite($fp, $htmlContainer);
    fclose($fp); 

    echo "Content saved successfully! View <a href='$contentFilePath' target='_blank'>$contentFilePath</a>";
} else {
    echo "Invalid request.";
}
?>
