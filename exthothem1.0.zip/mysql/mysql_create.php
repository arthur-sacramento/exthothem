﻿<?php

// Database connection settings
$servername = "localhost";  // Replace with your server name
$username = "root";  // Replace with your MySQL username
$password = "";  // Replace with your MySQL password
$dbname = "";  // Replace with your MySQL database name

// Create a new connection
$conn = new mysqli($servername, $username, $password);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS $dbname";
$conn->query($sql);

// Select the database
$conn->select_db($dbname);

// Create the table if it doesn't exist
$sql = "CREATE TABLE IF NOT EXISTS links (
    id INT AUTO_INCREMENT PRIMARY KEY,
    link VARCHAR(255) NOT NULL,
    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)";
$conn->query($sql);

// Insert a link into the database
$link = "https://www.example.com";  // Replace with your desired link

$sql = "INSERT INTO links (link) VALUES ('$link')";
if ($conn->query($sql) === TRUE) {
    echo "Link inserted successfully.";
} else {
    echo "Error inserting link: " . $conn->error;
}

// Close the database connection
$conn->close();

?>