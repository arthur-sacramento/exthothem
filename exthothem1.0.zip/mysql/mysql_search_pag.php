﻿<?php
// Assuming you have already established a MySQL database connection

// Database connection settings
$servername = "localhost";  // Replace with your server name
$username = "root";  // Replace with your MySQL username
$password = "";  // Replace with your MySQL password
$dbname = "";  // Replace with your MySQL database name

// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Number of links to display per page
$linksPerPage = 20;

// Get the current page number from the URL query string
$page = isset($_GET['page']) ? intval($_GET['page']) : 1;

// Calculate the offset for the SQL query
$offset = ($page - 1) * $linksPerPage;

// Get the search term from the URL query string
$searchTerm = isset($_GET['search']) ? $_GET['search'] : '';

// Construct the SQL query based on the search term and pagination
$sql = "SELECT * FROM links";
if (!empty($searchTerm)) {
    $sql .= " WHERE link LIKE '%$searchTerm%'";
}
$sql .= " ORDER BY date DESC LIMIT $offset, $linksPerPage";

// Execute the SQL query
$result = $conn->query($sql);

// Fetch the links from the result set
$links = $result->fetch_all(MYSQLI_ASSOC);

// Get the total number of links matching the search term
$sqlCount = "SELECT COUNT(*) FROM links";
if (!empty($searchTerm)) {
    $sqlCount .= " WHERE link LIKE '%$searchTerm%'";
}
$countResult = $conn->query($sqlCount);
$totalLinks = $countResult->fetch_array()[0];

// Calculate the total number of pages
$totalPages = ceil($totalLinks / $linksPerPage);
?>

<!DOCTYPE html>
<html>
<head>
    <title>Link Search</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
        }

        h1 {
            margin-bottom: 20px;
        }

        form {
            margin-bottom: 20px;
        }

        input[type="text"] {
            padding: 5px;
            width: 200px;
        }

        input[type="submit"] {
            padding: 5px 10px;
        }

        ul {
            list-style-type: none;
            padding: 0;
        }

        li {
            margin-bottom: 10px;
        }

        .pagination {
            margin-top: 20px;
        }

        .pagination a {
            display: inline-block;
            padding: 5px 10px;
            background-color: #f1f1f1;
            color: #333;
            text-decoration: none;
            border: 1px solid #ddd;
            margin-right: 5px;
        }

        .pagination a.active {
            background-color: #333;
            color: #fff;
        }
    </style>
</head>
<body>
    <h1>Link Search</h1>

    <form action="mysql_search_pag.php" method="GET">
        <label for="search">Search:</label>
        <input type="text" name="search" id="search" value="<?php echo $searchTerm; ?>">
        <input type="submit" value="Search">
    </form>

    <h2>Search Results</h2>
    <?php if (empty($links)): ?>
        <p>No results found.</p>
    <?php else: ?>
        <ul>
            <?php foreach ($links as $link): ?>
                <li><?php echo  "<a href='" . $link['link'] . "' tager='_blank'>" . $link['link'] . "</a>"; ?> (<?php echo $link['date']; ?>)</li>
            <?php endforeach; ?>
        </ul>
    <?php endif; ?>

    <div class="pagination">
        <?php if ($totalPages > 1): ?>
            <?php if ($page > 1): ?>
                <a href="?search=<?php echo urlencode($searchTerm); ?>&page=<?php echo ($page - 1); ?>">Previous</a>
            <?php endif; ?>

            <?php for ($i = 1; $i <= $totalPages; $i++): ?>
                <?php if ($i === $page): ?>
                    <a class="active" href="?search=<?php echo urlencode($searchTerm); ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                <?php else: ?>
                    <a href="?search=<?php echo urlencode($searchTerm); ?>&page=<?php echo $i; ?>"><?php echo $i; ?></a>
                <?php endif; ?>
            <?php endfor; ?>

            <?php if ($page < $totalPages): ?>
                <a href="?search=<?php echo urlencode($searchTerm); ?>&page=<?php echo ($page + 1); ?>">Next</a>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>


