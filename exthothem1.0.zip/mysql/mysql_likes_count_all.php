﻿<?php
// MySQL database credentials
$servername = 'localhost';
$username = 'root';
$password = '';
$database = '';

// Create a connection to the MySQL server
$conn = new mysqli($servername, $username, $password);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS $database";
$conn->query($sql);
$conn->select_db($database);

// Create the 'likes' table if it doesn't exist
$sql = "CREATE TABLE IF NOT EXISTS likes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_hash VARCHAR(255),
    link_id VARCHAR(255)
)";
$conn->query($sql);

// Function to count link repetitions
function countLinkRepetitions($linkID, $conn)
{
    // Prepare the SQL statement
    $stmt = $conn->prepare("SELECT COUNT(*) as count FROM likes WHERE link_id = ?");
    $stmt->bind_param("s", $linkID);
    
    // Execute the query
    $stmt->execute();
    
    // Fetch the result
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();
    
    // Return the count
    return $row['count'];
}

// Function to fetch the first ten records with the highest repetitions
function getTopRecords($conn)
{
    // Prepare the SQL statement
    $stmt = $conn->prepare("SELECT link_id, COUNT(*) AS count FROM likes GROUP BY link_id ORDER BY count DESC LIMIT 10");
    
    // Execute the query
    $stmt->execute();
    
    // Fetch the result
    $result = $stmt->get_result();
    
    // Fetch the records
    $records = [];
    while ($row = $result->fetch_assoc()) {
        $records[] = $row;
    }
    
    // Return the records
    return $records;
}

// Example usage
$linkID = 'example_link_id';

// Count the repetitions for the link
$count = countLinkRepetitions($linkID, $conn);
echo "The link with ID $linkID repeats $count times in the 'likes' table.";

// Get the first ten records with the highest repetitions
$topRecords = getTopRecords($conn);
echo "\n\nThe first ten records with the highest repetitions are:<br>";
foreach ($topRecords as $record) {
    echo "Link ID: {$record['link_id']}, Count: {$record['count']}<br>";
}

// Close the database connection
$conn->close();
?>
