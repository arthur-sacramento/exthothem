﻿<?php

// Database connection settings
$servername = "localhost";  // Replace with your server name
$username = "root";  // Replace with your MySQL username
$password = "";  // Replace with your MySQL password
$dbname = "";  // Replace with your MySQL database name

// Create a new connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user input from a form or any other source
$searchInput = 'ex';  // Replace with your method of obtaining user input

// Prepare the SQL query
$sql = "SELECT * FROM links WHERE link LIKE '%$searchInput%'";

// Execute the query
$result = $conn->query($sql);

// Check if any results were found
if ($result->num_rows > 0) {
    // Display the results
    while ($row = $result->fetch_assoc()) {
        echo "ID: " . $row["id"] . "<br>";
        echo "Link: " . $row["link"] . "<br>";
        echo "Date: " . $row["date"] . "<br>";
        echo "<br>";
    }
} else {
    echo "No results found.";
}

// Close the database connection
$conn->close();

?>