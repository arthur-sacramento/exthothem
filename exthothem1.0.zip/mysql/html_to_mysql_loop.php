﻿<?php
// MySQL database credentials
$host = 'localhost';
$username = 'root';
$password = '';
$database = '';

// Folder path
$folder = 'categories/';

// Connect to MySQL server
$connection = new mysqli($host, $username, $password, $database);
if ($connection->connect_error) {
    die('Connection failed: ' . $connection->connect_error);
}

// Create 'links' table if it doesn't exist
$query = "CREATE TABLE IF NOT EXISTS links (
    id INT AUTO_INCREMENT PRIMARY KEY,
    link VARCHAR(255) NOT NULL,
    date DATE NOT NULL
)";
$connection->query($query);

// Get list of folders
$folders = scandir($folder);

// Loop through each folder
foreach ($folders as $folderName) {
    // Skip . and .. folders
    if ($folderName === '.' || $folderName === '..') {
        continue;
    }

    // Get folder path
    $folderPath = $folder . $folderName;

    // Check if it's a directory
    if (is_dir($folderPath)) {
        // Get list of files in the folder
        $files = scandir($folderPath);

        // Loop through each file
        foreach ($files as $fileName) {
            // Skip . and .. files
            if ($fileName === '.' || $fileName === '..') {
                continue;
            }

            // Get file path
            $filePath = $folderPath . '/' . $fileName;

            // Read the file
            $html = file_get_contents($filePath);

            // Extract href attributes from a elements
            $dom = new DOMDocument();
            libxml_use_internal_errors(true); // Disable libxml errors
            $dom->loadHTML($html);
            libxml_clear_errors();

            $links = $dom->getElementsByTagName('a');
            $linkData = [];

            foreach ($links as $link) {
                $href = $link->getAttribute('href');
                if (!empty($href) && strpos($href, '.') !== 0) { // Check if href does not begin with a dot
                    $linkData[] = [
                        'link' => $href,
                        'date' => date('Y-m-d')
                    ];
                }
            }

            // Prepare and execute INSERT statement for each link
            $insertQuery = "INSERT INTO links (link, date) VALUES (?, ?)";
            $insertStatement = $connection->prepare($insertQuery);
            $insertStatement->bind_param("ss", $link, $date);

            foreach ($linkData as $data) {
                $link = $data['link'];
                $date = $data['date'];

                $insertStatement->execute();
            }

            // Close the prepared statement
            $insertStatement->close();
        }
    }
}

// Close the database connection
$connection->close();

echo "Links inserted successfully into the 'links' table.";
?>
