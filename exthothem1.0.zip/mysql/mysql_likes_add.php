﻿<?php
// MySQL database credentials
$servername = 'localhost';
$username = 'root';
$password = '';
$database = '';

// Create a connection to the MySQL server
$conn = new mysqli($servername, $username, $password);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Create the database if it doesn't exist
$sql = "CREATE DATABASE IF NOT EXISTS $database";
$conn->query($sql);
$conn->select_db($database);

// Create the 'likes' table if it doesn't exist
$sql = "CREATE TABLE IF NOT EXISTS likes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_hash VARCHAR(40),
    link_id VARCHAR(255),
    UNIQUE KEY unique_like (user_hash, link_id)
)";
$conn->query($sql);

// Function to generate SHA1 hash of user IP
function getUserHash() {
    if (!empty($_SERVER['HTTP_CLIENT_IP'])) {
        $ip = $_SERVER['HTTP_CLIENT_IP'];
    } elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
        $ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
    } else {
        $ip = $_SERVER['REMOTE_ADDR'];
    }

    return sha1($ip);
}

// Example usage
$userHash = getUserHash();
$linkID = 'example_link_id';

// Check if the combination of user_hash and link_id already exists
$stmt = $conn->prepare("SELECT id FROM likes WHERE user_hash = ? AND link_id = ?");
$stmt->bind_param("ss", $userHash, $linkID);
$stmt->execute();
$stmt->store_result();
$count = $stmt->num_rows;

if ($count > 0) {
    echo "This combination already exists in the 'likes' table.";
} else {
    // Insert the new record
    $stmt = $conn->prepare("INSERT INTO likes (user_hash, link_id) VALUES (?, ?)");
    $stmt->bind_param("ss", $userHash, $linkID);
    $stmt->execute();
    echo "New record inserted successfully.";
}

// Close the database connection
$conn->close();
?>