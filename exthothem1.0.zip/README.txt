It's easy share and backup with Exthothem
-----------------------------------------

You are free to use and edit this software as long as it's not for commercial purposes.
If you wish to use it for commercial purposes, please contact us to obtain permission.

We do not take responsibility for the content made available by third parties or by users using our application.
Additionally, we do not provide any guarantees regarding the security or integrity of data in the user system.


Donations:

Pix   : exthothem@gmail.com
PayPal: https://www.paypal.com/donate/?hosted_button_id=MA7KAL6PP4Y7Q
BTC   : 1CX6rNZnBexgTW8HW8VRhBoKAG3TsNc9Em


________________________________________________________________________________________________

If you need a freelance PHP programmer you can contact via:

https://www.linkedin.com/in/arthur-sacramento-a55003230/
http://wa.me/5591983608861
https://chat.whatsapp.com/LvWpR495NDZ2wLvjs6KqyO
https://github.com/arthur-sacramento
exthothem@gmail.com


