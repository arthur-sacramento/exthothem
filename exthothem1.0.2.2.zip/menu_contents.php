﻿  <div align='center'>
    <table>
      <tr>
        <td>
          <div align='left'>
          <span class='textDescription'>NoSQL PHP applications</span> 
          </div>
        </td>
        <td style='background-color: #333;'>
        </td>
      </tr>
    </table>
    <br>
    <table style='background-color: #DDD;'>
      <tr>
        <td style='border-right: 1px solid #CCC;'>      
          <div align='center'>
          <table style='background-color: #FFF;'>
            <tr>
              <td><a href="index.php"><img src='icons/table.png' alt=''><br>Flat database</a></td>
              <td><a href="fields_search.php"><img src='icons/application_form_magnify.png' alt=''><br>Search by file contents</a></td>
              <td><a href="flat_insert_link.php"><img src='icons/backslash.png' alt=''><br>Share a link</a></td>
              <td><a href="gallery_creator.php"><img src='icons/images.png' alt=''><br>Gallery creator</a> / <a href="gallery_list.php" target="_blank">List</a></td>
              </tr>
            <tr>
              <td><a href="upload.php"><img src='icons/netvibes.png' alt=''><br>Upload a file (select)</a></td>
              <td><a href="upload_drop.php"><img src='icons/package_add.png' alt=''><br>Upload a file (drop)</a></td>
              <td><a href="fields.php"><img src='icons/document_copies.png' alt=''><br>Paste contents (multiple fields)</a></td>
              <td><a href="paste.php"><img src='icons/document_empty.png' alt=''><br>Paste contents (one field)</a></td>
            </tr>
            <tr>
              <td><a href="write_get.php"><img src='icons/attach.png' alt=''><br>Send text via GET contents</a></td>  
              <td><a href="folders.php"><img src='icons/document_green.png' alt=''><br>Folders menu</a></td>  
              <td><a href="files_full.php"><img src='icons/understanding.png' alt=''><br>Full search</a></td>
              <td><a href="files.php"><img src='icons/folder_explorer.png' alt=''><br>Category search</a></td>
            </tr>
            <tr>
              <td><a href="chat.php"><img src='icons/comment.png' alt=''><br>Chat</a></td>
              <td><a href="comment.php?hash=hello"><img src='icons/comment.png' alt=''><br>Comment</a></td>
              <td><a href="servers.php"><img src='icons/globe_australia.png' alt=''><br>Check servers</a></td>        
              <td><a href="all_files.php"><img src='icons/list.png' alt=''><br>Show all files</a></td>  
            </tr>
            <tr>      
              <td><a href="main.php"><img src='icons/image.png' alt=''><br>URL upload</a></td>      
              <td><a href="menu.html"><img src='icons/controlbar.png' alt=''><br>Menu</a></td>
              <td><a href="#"><img src='icons/coins_in_hand.png' alt=''><a href='https://www.paypal.com/donate/?hosted_button_id=MA7KAL6PP4Y7Q' target='_blank'>Donate</a> / <a href='#' onclick="alert('1CX6rNZnBexgTW8HW8VRhBoKAG3TsNc9Em');">BTC</a> / <a href='#' onclick="alert('exthothem@gmail.com');">Pix</a> </td>     
              <td><a href='exthothem1.0.2.2.zip'><img src='icons/download.png' alt=''><br>Sourcecode</a></td>
            </tr>
            <tr>      
              <td><a href="img_thumbs_creator.php"><img src='icons/image.png' alt=''><br>Thumbnail creator<br>(thumbs folder)</a></td>      
              <td><a href="img_decrease.php"><img src='icons/image_gray.png' alt=''><br>Image compress</a></td>    
              <td><a href='img_random.php'><img src='icons/dice.png' alt=''><br>Random image<br>generator</a></td>
              <td><a href="README.txt"><img src='icons/help.png' alt=''><br>README</a></td>                   
            </tr>
            <tr>      
              <td><a href="table_row_delete.php"><img src='icons/image.png' alt=''><br>Delete row</a></td>      
              <td><a href="table_row_update.php"><img src='icons/image_gray.png' alt=''><br>Update row</a></td>    
              <td><a href='table_submit.php'><img src='icons/dice.png' alt=''><br>Save a list of links as table</a></td>
              <td><a href="README.txt"><img src='icons/help.png' alt=''><br>PHP freelancer</a></td>                   
            </tr>
          </table> 
        </td>
        <td style='background-color: #333;'></td>
      </tr>
    </table>
  <br><iframe src='https://filevenda.netlify.app/categories/ads.html' width='100%' style='border: 0px;'></iframe>
  </div>