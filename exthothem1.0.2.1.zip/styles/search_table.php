﻿<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Table Filter</title>
</head>
<body>
    <form method="post">
        <label for="search">Search:</label>
        <input type="text" name="search" id="search" placeholder="Enter search text">
        <input type="submit" value="Filter">
    </form>

    <?php
    if ($_SERVER["REQUEST_METHOD"] == "POST") {
        // Get user input
        $searchText = isset($_POST["search"]) ? $_POST["search"] : "";

        // Load the HTML content (you can replace this with your own HTML file)
        $html = '<table>
                    <tr><td>Apple</td><td>Red</td></tr>
                    <tr><td>Banana</td><td>Yellow</td></tr>
                    <tr><td>Cherry</td><td>Red</td></tr>
                    <tr><td>Grape</td><td>Purple</td></tr>
                    <tr><td>Lemon</td><td>Yellow</td></tr>
                </table>';

        $dom = new DOMDocument();
        @$dom->loadHTML($html); // Suppress warnings, as HTML may not be perfect

        // Create a DOMXPath object to query the DOM
        $xpath = new DOMXPath($dom);

        // Query the rows that contain the search text
        $query = "//tr[contains(translate(td/text(), 'ABCDEFGHIJKLMNOPQRSTUVWXYZ', 'abcdefghijklmnopqrstuvwxyz'), '" . strtolower($searchText) . "')]";

        $filteredRows = $xpath->query($query);

        // Display the filtered rows
        if ($filteredRows->length > 0) {
            echo '<table>';
            foreach ($filteredRows as $row) {
                echo $dom->saveHTML($row);
            }
            echo '</table>';
        } else {
            echo "No matching rows found.";
        }
    }
    ?>
</body>
</html>
